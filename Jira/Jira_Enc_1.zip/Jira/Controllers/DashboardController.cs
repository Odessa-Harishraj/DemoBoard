﻿using Microsoft.AspNetCore.Mvc;

namespace JiraClone.Controllers
{
    public class DashboardController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }
    }
}
