﻿using Microsoft.EntityFrameworkCore;

namespace JiraClone.Data
{
    public class AppDbContext : DbContext
    {
        public AppDbContext(DbContextOptions<AppDbContext> options) : base(options) { }

        public DbSet<Project> Projects => Set<Project>();

        public DbSet<Board> Boards { get; set; }

        public DbSet<WorkItem> WorkItems { get; set; }

        public DbSet<StatusConfig> StatusConfigs { get; set; }

        protected override void OnModelCreating(ModelBuilder modelBuilder)
        {
            base.OnModelCreating(modelBuilder);

            // Avoid multiple cascade paths: prevent cascading delete from Project to WorkItems directly
            modelBuilder.Entity<WorkItem>()
                .HasOne(w => w.Project)
                .WithMany()
                .HasForeignKey(w => w.ProjectId)
                .OnDelete(DeleteBehavior.NoAction);

            // Keep cascades that are safe
            modelBuilder.Entity<Board>()
                .HasOne(b => b.Project)
                .WithMany(p => p.Boards)
                .HasForeignKey(b => b.ProjectId)
                .OnDelete(DeleteBehavior.Cascade);

            modelBuilder.Entity<WorkItem>()
                .HasOne(w => w.Board)
                .WithMany(b => b.WorkItems)
                .HasForeignKey(w => w.BoardId)
                .OnDelete(DeleteBehavior.Cascade);
        }
    }
}
