﻿namespace JiraClone.Data
{
    public class StatusConfig
    {
        public int Id { get; set; }
        public string Name { get; set; } = "";
    }
}